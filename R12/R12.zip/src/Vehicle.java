
public class Vehicle {
	int x, y, w, h, vx, vy, cx, cy, r, c;
	
    public Vehicle (int x, int y, int w, int h, int vx, int vy) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.vx = vx;
        this.vy = vy;
 
    }
	 public void move() {
	        x += vx;
	        y += vy;
	    }
}
